<?php
/*
class Languages{
	
	public function __construct(){
		$lang = '';
		$language = '';
		if(!isset($_SESSION['language'])){
		$language = 'es';
		}
		if(!empty($language)){
			$_SESSION["language"] = $language;
		}
		if(isset($_SESSION['language'])){
			$language = $_SESSION["language"];
			require_once "../language/lang/".$language.".php";
		}else{
			require_once "../language/lang/es.php";
		}
	}
}
*/
