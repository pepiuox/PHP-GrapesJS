<script src="<?php echo SITE_PATH; ?>assets/js/image-scale.min.js" type="text/javascript"></script>
<script src="<?php echo SITE_PATH; ?>assets/js/gallerycontent.js" type="text/javascript"></script>
<link href="<?php echo SITE_PATH; ?>assets/css/gallerycontent.css" rel="stylesheet" type="text/css"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jScrollPane/2.0.23/script/jquery.jscrollpane.min.js" type="text/javascript"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/jScrollPane/2.0.23/style/jquery.jscrollpane.min.css" rel="stylesheet" type="text/css"/>