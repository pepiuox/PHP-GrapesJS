<style>
    form.br{       
        font-size: 13px;
        color: #999999;
        padding-left: 20px;        
    }
    form.br label{
        color: #999999;
        font-size: 13px;
    }
    .infocontact{
        float: right;
        margin-top: 55px;
    }
    .infocontact table{
        border: 0;
    }
    .infocontact td{
        background: #ffffff;
    }
    .infocontact td img{
        width: 15px;
    }
    .infocontact a{
        color: #999999;
    }
    .infocontact p{  
        font-size: 13px;
        color: #999999;
        text-align: right;
        margin-right: 10px;
    }
    .infcont{
        font-size: 13px;
        width: 100%;
        text-align: right;
        padding-right: 40px;
    }
    .error {font-size: 13px; color: #FF0000;}
</style>