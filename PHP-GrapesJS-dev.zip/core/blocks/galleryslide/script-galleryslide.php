<script src="<?php echo SITE_PATH; ?>assets/js/image-scale.min.js" type="text/javascript"></script>
<script src="<?php echo SITE_PATH; ?>assets/js/galleryslide.js" type="text/javascript"></script>
<link href="<?php echo SITE_PATH; ?>assets/css/galleryslide.css" rel="stylesheet" type="text/css"/>
