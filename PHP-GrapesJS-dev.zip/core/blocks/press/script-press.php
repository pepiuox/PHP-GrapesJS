<script src="<?php echo SITE_PATH; ?>assets/js/image-scale.min.js" type="text/javascript"></script>
<link href="<?php echo SITE_PATH; ?>assets/css/press.css" rel="stylesheet" type="text/css"/>
<script src="<?php echo SITE_PATH; ?>assets/js/jquery.jscrollpane.min.js" type="text/javascript"></script>