<script src="<?php echo SITE_PATH; ?>assets/js/image-scale.min.js" type="text/javascript"></script>
<script src="<?php echo SITE_PATH; ?>assets/js/slide.js" type="text/javascript"></script>
<link href="<?php echo SITE_PATH; ?>assets/css/slide.css" rel="stylesheet" type="text/css"/>