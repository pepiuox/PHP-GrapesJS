<script src="<?php echo SITE_PATH; ?>assets/js/image-scale.min.js" type="text/javascript"></script>
<script src="<?php echo SITE_PATH; ?>assets/js/galleryvideo.js" type="text/javascript"></script>
<link href="<?php echo SITE_PATH; ?>assets/css/galleryvideo.css" rel="stylesheet" type="text/css"/>
