<div id="content" class="container background">
    <div class="row justify-content-center">
        <div class="col-md-6 mt-4 text-center bg-itswhite">
            <h3><?php echo SITE_NAME; ?></h3>
            <div class="text-center">
                <hr>
                <p class="text-center">
                    <strong>Administration system </strong> , Includes PIN security and password.  <br> <br>
                </p>
                <p class="text-center">
                    <a href="login.php"><span class="glyphicon glyphicon-log-in"></span>
                        Iniciar sesión</a>
                </p>
            </div>
        </div>
    </div>
</div>


