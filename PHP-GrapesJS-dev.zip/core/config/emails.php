<?php
define('MAIL_SUPPORT','support@esrapi.com');
define('SUBJECT_SUPPORT','ESRAPI');
define('MAIL_HELP','icon-pepiuox.png');
define('SUBJECT_HELP','http://localhost:180/');
define('MAIL_FAQ','icon-pepiuox.png');
define('SUBJECT_FAQ','http://localhost:180/');
 ?>
