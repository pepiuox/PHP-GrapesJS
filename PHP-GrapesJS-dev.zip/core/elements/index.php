<?php
$url = '../index.php';
header('Location: ' . $url);
exit;
?>
